﻿using System;
using Ckode.Caching;

namespace Ckode.DaLi.Queries
{
	public class CacheSettings
	{
		public bool Enabled { get; set; }
		public ExpirationType ExpirationType { get; set; }
		public TimeSpan ExpirationTime { get; set; }
		public bool Flush { get; set; }

		public CacheSettings(bool enabled, ExpirationType expirationType, TimeSpan expirationTime)
		{
			this.Enabled = enabled;
			this.ExpirationType = expirationType;
			this.ExpirationTime = expirationTime;
			this.Flush = false;
		}
	}
}
